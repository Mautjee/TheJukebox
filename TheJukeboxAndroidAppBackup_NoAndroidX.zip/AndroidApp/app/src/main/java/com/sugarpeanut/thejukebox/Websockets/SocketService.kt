package com.sugarpeanut.thejukebox.Websockets

//import com.tinder.scarlet.ws.Receive
//import com.tinder.scarlet.ws.Send
//import io.reactivex.Flowable

interface SocketService {

//    @Send
//    fun subscribe(action:SubscribeAction)
//
//    @Receive
//    fun observeTicker(): Flowable<TickerResponse>
//
//    @Receive
//    fun observerWebsocketEvent():Flowable<Websocket.Event>
}   