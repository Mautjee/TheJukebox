package com.sugarpeanut.thejukebox.Websockets

data class testMessage(val text:String)