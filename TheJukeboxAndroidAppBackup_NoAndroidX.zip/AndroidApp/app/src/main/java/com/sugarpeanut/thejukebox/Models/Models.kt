package com.sugarpeanut.thejukebox.Models

data class addSong(val playlistId:Int, val songjson:String)
