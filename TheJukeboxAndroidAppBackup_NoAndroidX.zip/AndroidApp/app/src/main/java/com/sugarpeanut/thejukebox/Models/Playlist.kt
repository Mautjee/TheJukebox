package com.sugarpeanut.thejukebox.Models

class Playlist(val playlistId :Int = 0,val songs :List<Song>)